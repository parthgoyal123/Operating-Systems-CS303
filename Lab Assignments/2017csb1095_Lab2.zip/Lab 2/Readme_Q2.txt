/* ------------------ Question 2 Lab2 CS303 - Operating Systems ------------------- */
					      Submitted by - Parth Goyal (2017csb1095)

# --- How to run the code ---- #
1. Run the command : make
The makefile present in the file will compile

2. Load the kernel module
Run the command : sudo insmod 2017csb1095_Q2.ko

3. Check whether the module has loaded successfully.
Run the command : dmesg

4. Removing the kernel module
Run the command : sudo rmmod 2017csb1095_Q2.ko
