/* ------------------ Question 1 Lab2 CS303 - Operating Systems ------------------- */
					      Submitted by - Parth Goyal (2017csb1095)

# --- How to run the code ---- #
We have our source file with some text in it.

Run the code : gcc -o Q1 Q1.c && ./Q1 source.txt destination.txt

This copies text of source file to destination file.
