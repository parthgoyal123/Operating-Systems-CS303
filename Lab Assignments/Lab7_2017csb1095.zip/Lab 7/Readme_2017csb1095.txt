/*------ README ------*/
CS303 Operating Systems LAB7
Submitted By - 2017csb1095 Parth Goyal

# ---- HOW TO RUN THE CODE ----- #
1. gcc -o virtual virtual_memory.c
2. ./virtual BACKING_STORE.bin addresses.txt > output.txt