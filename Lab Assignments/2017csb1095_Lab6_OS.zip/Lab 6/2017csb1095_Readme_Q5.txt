# -------- README -------- #

Question 5:

Compile and Run : --> gcc -o addresses 2017csb1095_Q5_Lab6.c && ./addresses -195 09444 0904 44967295
		      gcc -o addresses 2017csb1095_Q5_Lab6.c && ./addresses <virtual address(s)>
