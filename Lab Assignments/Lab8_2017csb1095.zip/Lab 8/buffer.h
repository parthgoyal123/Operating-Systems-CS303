/* Lab 8 Producer-Consumer Project (buffer.h)
 * Parth Goyal 2017CSB1095
 * CS303 Operating Systems
 * Deadline: 14/11/19
 *
 * Provides header for producer-consumer.c
 */
 
typedef int buffer_item;
#define BUFFER_SIZE 5