// ------ README ------- //
                - Parth Goyal (2017CSB1095)
                - CS303 Operating Systems
                - Lab8

** HOW TO RUN THE CODE **

1.   make clean
2.   make
3.   ./producer_consumer <sleep time> <producer count> <counsumer count>